import React from 'react';

const ContactUS = () => {
    return(
        <>
            <h1>this is a contact page </h1>
        </>
    )
}
export default ContactUS;