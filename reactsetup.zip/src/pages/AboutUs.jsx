import React from 'react';

const AboutUs = () => {
    return(
        <>
            <h1>this is a About page</h1>
        </>
    )
}
export default AboutUs;