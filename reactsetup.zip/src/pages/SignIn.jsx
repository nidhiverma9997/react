import React from 'react';
import { Formik, Form, Field, ErrorMessage, } from "formik";
import * as Yup from "yup";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom'

const LoginSchema = Yup.object().shape({
    email: Yup.string()
        .email("Invalid email address format")
        .required("Email is required"),
    password: Yup.string()
        .max(8, "Password must be 8 characters at minimum")
        .required("Password is required"),
});
const SignIn = () => {

    let navigate = useNavigate();

    return (
        <>
            <div className="card container mt-5" style={{ width: "35%" }}>
                <Formik
                    initialValues={{ email: "", password: "" }}
                    validationSchema={LoginSchema}
                    onSubmit={(values) => {
                        console.log(values);
                        toast.success("Login successfully!");
                        navigate("/");
                    }}
                >
                    {({ touched, errors, isSubmitting, values }) =>
                    (
                        <div>
                            <div className="card-body row p-2">
                                <div className="card-title col-lg-12 text-center">
                                    <h3 className=""> Sign In Page</h3>
                                </div>
                            </div>
                            <Form>
                                <div className="form-group">
                                    <label htmlFor="email">Email</label>
                                    <Field
                                        type="email"
                                        name="email"
                                        placeholder="Enter email"
                                        autocomplete="off"
                                        className={`mt-2 form-control
                          ${touched.email && errors.email ? "is-invalid" : ""}`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="email"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="password" className="mt-3">
                                        Password
                                    </label>
                                    <Field
                                        type="password"
                                        name="password"
                                        placeholder="Enter password"
                                        className={`mt-2 form-control
                          ${touched.password && errors.password
                                                ? "is-invalid"
                                                : ""
                                            }`}
                                    />
                                    <ErrorMessage
                                        component="div"
                                        name="password"
                                        className="invalid-feedback"
                                    />
                                </div>
                                <button
                                    type="submit"
                                    className="btn btn-primary btn-block m-4">
                                    Submit
                                </button>
                            </Form>
                        </div>
                    )
                    }
                </Formik>
                <ToastContainer />
            </div>
        </>
    )
}
export default SignIn;