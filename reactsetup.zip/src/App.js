import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link }
    from 'react-router-dom';
import { Nav, Row, Button } from 'react-bootstrap';
import './App.css';
import Home from './pages/Home';
import AboutUs from './pages/AboutUs';
import ContactUS from './pages/ContactUS';
import Product from './pages/Product';
import SignIn from './pages/SignIn';
import ListManagement from './components/ListManagement';
import DataEntryForm from './components/DataEntryForm';
// import SignOut from './pages/SignOut';

const App = () => {
    return (
        <div className='App'>
            <Router>
                <div className='container-fluid'>
                    <Row className='navbar-nav'>
                        <Nav className="navbar navbar-expand-lg navbar-dark bg-dark ">
                            <Link className="navbar-brand  p-2" to='#'>CMD</Link>
                            <div className="collapse navbar-collapse row" >
                                <div className="navbar-nav col-md-10">
                                    <div className="nav-item active">
                                        <Link className="nav-link" to='/'>Home</Link>
                                    </div>

                                    <div className="nav-item">
                                        <Link className="nav-link" to='aboutUs'>About Us</Link>
                                    </div>

                                    <div className="nav-item">
                                        <Link className="nav-link" to='contactUS'>Contact Us</Link>
                                    </div>

                                    <div className="nav-item">
                                        <Link className="nav-link" to='product'>Product Us</Link>
                                    </div>

                                    <div className="nav-item">
                                        <Link className="nav-link disabled" to='' tabindex="-1"
                                            aria-disabled="true">Disabled</Link>
                                    </div>
                                </div>
                                <div className='navbar-nav col-md-2 text-end'>
                                    <div className="nav-item">
                                        <Link className="nav-link" to='signIn'>
                                            <Button className="btn btn-success float-right text-light" type="button"
                                            >Sign In</Button>
                                        </Link>
                                    </div>
                                    <div className="nav-item  text-end">
                                        <Link className="nav-link" to='signIn'>
                                            <Button className="btn btn-outline-success float-right text-light" type="button"
                                            >Sign Out</Button>
                                        </Link>
                                    </div>

                                </div>
                            </div>
                        </Nav>
                    </Row>
                </div>
                <Routes>
                    <Route path='/' element={<Home />} />
                    <Route path='/aboutUs' element={<AboutUs />} />
                    <Route path='/contactUS' element={<ContactUS />} />
                    <Route path='/product' element={<Product />} />
                    <Route path='/signIn' element={<SignIn />} />
                    {/* <Route path='/signOut' element={<SignOut />} /> */}
                    <Route path='/listManagement' element={<ListManagement />} />
                    <Route path='/dataEntryForm' element={<DataEntryForm/>}/>
                </Routes>
            </Router>
        </div>
    )
}
export default App;