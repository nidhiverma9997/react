import React,{useState} from 'react';
import { Table, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import { Rings  } from 'react-loader-spinner';

const ListManagement = () => {
    const dataList = [
        {
            id: 1,
            firstName: 'Arti',
            lastName: 'Sharma',
            email: 'arti23@gmail.com'
        },
        {
            id: 2,
            firstName: 'Gagan',
            lastName: 'Rajput',
            email: 'gagan24@gmil.com'
        },
        {
            id: 3,
            firstName: 'Garima',
            lastName: 'Rana',
            email: 'garima56@gmail.com'
        },
        {
            id: 4,
            firstName: 'Shweta',
            lastName: 'Ravat',
            email: 'shweta76@gmail.com'
        },
        {
            id: 5,
            firstName: 'Anuj',
            lastName: 'Verma',
            email: 'anuj65@gmail.com'
        },
        {
            id: 6,
            firstName: 'Shubham',
            lastName: 'Verma',
            email: 'shubham87@gmail.com'
        },
        {
            id: 7,
            firstName: 'Reetu',
            lastName: 'Yadav',
            email: 'reetu98@gmail.com'
        },
        {
            id: 8,
            firstName: 'Sunil',
            lastName: 'Yadav',
            email: 'sunil87@gmail.com'
        },
        {
            id: 9,
            firstName: 'Manu',
            lastName: 'Thakur',
            email: 'manu45@gmail.com'
        },
        {
            id: 10,
            firstName: 'Anu',
            lastName: 'Gupta',
            email: 'anu56@gmail.com'
        },
    ]
    console.log('dataList>>', dataList)

    const [getData, setGetData] = useState(dataList);

    const addData = (id) => {
        alert(id)
        const newUpdateData = getData.filter((item) => {
            return item.id == id;
        })
        setGetData(newUpdateData);
    }
    
    const deleteData = (id) => {
        // alert(id);
        const newData = getData.filter((item) => {
            return item.id !== id;
        })
        setGetData(newData);
    }
    return (
        <>
            <div className='card mt-5 container' style={{ width: '80%' }}>
                <div className='card-body '>
                    <div className='card-title'>
                        <div className='row'>
                            <h3 className='text-start col-md-6'>List Management Data</h3>
                            <div className='col-md-6 bg-light text-end mb-3'>
                                <Link to={``}>
                                    <Button className='btn btn-primary btn-lg float-right'>Add User</Button>
                                </Link>
                            </div>
                        </div>
                        <div>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                       dataList.length > 0 ? dataList.map((item) => (
                                            <tr>
                                                <td>{item.id}</td>
                                                <td>{item.firstName}</td>
                                                <td>{item.lastName}</td>
                                                <td>{item.email}</td>
                                                <td>
                                                    <Link to={''}>
                                                        <Button variant="info"
                                                            onClick={() => addData(item.id)}>Edit</Button>
                                                    </Link>
                                                </td>
                                                <td>
                                                    <Button variant="danger"
                                                        onClick={() => deleteData(item.id)}>
                                                        Delete
                                                    </Button>
                                                </td>
                                            </tr>
                                        ))
                                        :<Rings  height={80} width={100} /> 
                                    }
                                     
                                </tbody>
                            </Table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default ListManagement;