import React from 'react';

const EditData = () => {
    return(
        <>
            
        </>
    )
}
export default EditData;